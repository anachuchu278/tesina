<?php 
namespace App\Models;

use CodeIgniter\Model;

class UsuarioModelo extends Model{ 

    protected $table = 'usuario';
    protected $primaryKey = 'id_Usuario'; 
  
    protected $useAutoIncrement = true; 

    protected $allowedFields = ['nombre','password','email','id_rol','id_especialidad','id_horamed']; 
}