<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */



$routes->get('/','RegisterControlador::index'); 
$routes->post('register', 'RegisterControlador::registrarse'); 
$routes->get('login', 'RegisterControlador::registrarse');
$routes->post('login', 'LoginControlador::loguearse'); 
$routes->get('test', 'LoginControlador::loguearse');