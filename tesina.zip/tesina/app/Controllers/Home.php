<?php

namespace App\Controllers;

class Home extends BaseController
{
    
}
